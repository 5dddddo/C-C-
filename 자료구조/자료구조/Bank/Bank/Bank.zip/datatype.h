#pragma once
typedef struct _customer
{
	int number;
	char job[8];
}Customer;
typedef Customer DataType;